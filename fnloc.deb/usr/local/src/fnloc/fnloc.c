/*
 * FILE
 *      fnloc.c - version 2.3
 * NAME
 *      Copyright 2018 Richard B. Romig
 * EMAIL
 *      rick.romig@gmail.com
 * DATE
 *      6 September 2018
 * DESCRIPTION
 * Counts logical lines of code, skipping comments and blank lines.
 * Count number of functions and lines of code within the functions.
 * Prints a summary upon completion showing the number of functions, total
 * lines of code contained in functions, total lines of code outside of
 * functions, and total lines of code in the program. If the source code
 * contains no functions, as in a header file, it displays that it contains
 * no functions and shows the tocal LOC for the file.
 *
 * LIMITATIONS
 *  Target file must be a text file of C/C++ source code. Results for C source
 *  code written in old style style may not be correct as they may not conform
 *  to ANSI/ISO coding standards.
 ******************************************************************************
 *
 *  To be counted properly functions must take the following form:
 *  int function_name(int x)
 *  {
 * 	statements:
 *  }
 *
 * Function headers that are split into two lines, are counted as functions,
 * their function loc is counted correctly and both lines of the  header are
 * displayed in the output.
 ******************************************************************************
 *
 * Data structures must be written in the following form:
 *  struct foo {
 *   int a;
 *   float b;
 *  };
 *
 * Structures written with the opening braces in the first column will be
 * processed as if they are functions.
 *
 * In data structure declarations such as arrays or enumerated types in which
 * the data elements are delimited by commas, the elements inside the braces
 * are not counted if they are not on the same line as a brace. The first and
 * last lines (the lines with the braces) of the declaration are counted.
 ******************************************************************************
 *
 * if, else, for, while, do constructs without braces and only one statement
 *  ending with ';' following will be counted as one line of code.
 *
 * if ( condition )
 * 	action;
 *
 * for ( i = 1; i < 10; i++ )
 * 	if ( condition )
 * 		action;
 *
 * These will each be counted as one line of code when the first ';' at the
 * end of a line is reached.
 ******************************************************************************
 *
 * COMPILER INFO
 *      gcc  (Ubuntu 7.3.0-27ubuntu1~18.04) 7.3.0 on Linux Mint 19.1
 *      MinGW gcc on Windows 7
 *
 * MODIFICATION HISTORY
 * 4 Sep 2018 	Fixed the problem with counting and identifying mult-line
 * 		function headers.
 * 6 Sep 2018 	Implemented a singly linked list to replace the stack so that
 *		the function listing in the output would be in the same order
 *		as the source code file.
 *		Simplified the data structures. Data is input to the linked
 *		list from temporary variables in main()
 *		Replaced the function to print the output into three separate
 *		functions to display information about the program itself,
 *		another to display function names and loc (if any), and a
 *		function to display a summary of the results.
 * 19 Nov 2018  Modified data structures to hold a possible second line of a
 *		function header.
 *		Revised code to initialize string variables to hold function
 *		names, copy line buffers to them and reset to empty.
 *		Modified linked list functions to handle additional data.
 * 29 Jan 2018  Incorporated lstates.h and lstates.c to combine common functions
 * 		between lloc and fnloc for determining states of the examined lines.
******************************************************************************
 *
 * GNU Public License, Version 2
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "fnloc.h"
#include "lstates.h"

int main(int argc, char *argv[])
{
	FILE *fp;

	/* buffers */
	char buffer[BUF_LEN];	/* line of source code being examined */
	char fn_name1[BUF_LEN];	/* function name */
	char fn_name2[BUF_LEN];	/* 2nd line of function name */

	int prg_loc = 0;	/* running loc count */
	int fn_loc = 0;		/* lines of code in current function */
	int fn_count = 0;	/* running function count */
	int total_fn_loc = 0;	/* running function loc count */
	int i;			/* for loop index */

	/* initial line and function states */
	STATETYPE state = NewLine;
	FNSTATETYPE fn_state = NotFunction;
	strcpy(fn_name1, "");
	strcpy(fn_name2, "");

	if ( argc < 2 )
	{
		fprintf(stderr, "No source code file passed.\n");
		show_usage(argv[0]);
		exit(1);
	}

	if ( (strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "--help") == 0) )
	{
		 show_usage(argv[0]);
		 exit(1);
	}

	fp = fopen(argv[1], "r");
	if ( fp == NULL )
	{
		fprintf(stderr, "Cannot open %s\n", argv[1]);
		show_usage(argv[0]);
		exit(1);
	}

	while ( !feof(fp) )
	{
		if ( fgets(buffer, BUF_LEN, fp) )
		{
			for( i = 0; i < strlen(buffer); i++ )
		        {
		                switch(state)
		                {
		                case(NewLine) :
		                        state = next_new_line(buffer[i]);
		                        break;
		                case (NewLineNC) :
		                        break;
		                case(PosComment) :
		                        state = next_pos_comment(buffer[i]);
		                        break;
		                case(CppComment) :
		                        state = next_cpp_comment(buffer[i]);
		                        break;
		                case(Comment) :
		                        state = next_comment(buffer[i]);
		                        break;
		                case(PosEndComment) :
		                        state = next_pos_end_comment(buffer[i]);
		                        break;
		                case(EndComment) :
		                        state =  NewLineNC;
		                        break;
		                case(CompDir) :
		                        state = next_comp_dir(buffer[i]);
		                        break;
		                case(LineOfCode) :
		                        state = next_line_of_code(buffer[i]);
		                        break;
		                case(OpenBracket) :
		                        state = next_open_bracket(buffer[i]);
		                        break;
		                case(CloseBracket1) :
		                        state = next_close_bracket1(buffer[i]);
		                        break;
		                case(CloseBracket2) :
		                        state = next_close_bracket2(buffer[i]);
		                        break;
		                case(PosEOL) :
		                        state = next_pos_eol(buffer[i]);
		                        break;
		                case(InlineComment) :
		                        state = next_inline_comment(buffer[i]);
		                        break;
		                } /* end switch(state) */
		        }  /* end for loop */

			if ( isalpha(buffer[0]) )
			{
				fn_state = PosFunction;
				strcpy(fn_name1, buffer);
				strcpy(fn_name2, "");
				fn_loc = 0;
			}

			if ( fn_state == PosFunction )
			{
				switch (buffer[0])
				{
					case '{':
						fn_state = IsFunction;
						fn_count++;
						break;
					case ' ':
					case '\t':
						strcpy(fn_name2, buffer);
						break;
					case '}':
						fn_state = NotFunction;
						strcpy(fn_name1, "");
						strcpy(fn_name2, "");
				}
			}

			if ( state == NewLine )
				prg_loc++;

			if ( state == NewLine && fn_state == IsFunction )
			{
				fn_loc++;
				total_fn_loc++;
			}

			if ( state == NewLineNC )
				state = NewLine;

			if ( fn_state == IsFunction && buffer[0] == '}' )
			{
				insert_at_end(fn_name1, fn_name2, fn_loc);
				fn_state = NotFunction;
				strcpy(fn_name1, "");
				strcpy(fn_name2, "");
				fn_loc = 0;
			}
		}	/* end if(fgets) */
	}	/* end while loop */

	/* Display output */
	print_intro(argv[1]);
	print_fn_data(argv[1], fn_count, prg_loc);
	if ( fn_count != 0 )
		print_summary(fn_count, total_fn_loc, prg_loc);

	/* Clean up */
	fclose(fp);
	head = free_list(head);

	return 0;
}

/*
 * FUNCTION
 *	void insert_at_end(fn_name, char fn_name2[], fn_loc)
 * DESCRIPTION
 *	inserts data into a singly linked list at the head if it is the first
 *	item, otherwise at the end.
 * PARAMETERS
 *	char fn_name[]	- character string holding the current function name
 *	char fn_name2[] - character strng holding second line of function name
 *	int fn_loc - integer holding the number of loc in the function
 * RETURN VALUE
 *	None, inserts data into the linked list
 */
void insert_at_end(char fn_name1[], char fn_name2[], int fn_loc)
{
	node *current;
	current = (node*)malloc(sizeof(node));

	if ( current == NULL )
	{
		fprintf(stderr, "Out of space\n");
		exit(1);
	}
	else
	{
		strcpy(current->name1, fn_name1);
		strcpy(current->name2, fn_name2);
		current->loc = fn_loc;
		current->next = NULL;

		if ( head == NULL )
		{
			head = current;
			last = current;
		}
		else
		{
			last->next = current;
			last = current;
		}
	}
}

/*
 * FUNCTION
 *	void delete_list(node *head)
 * DESCRIPTION
 *	frees the memory allocated for the list
 * PARAMETERS
 *	node *head - the head of the linked list
 * RETURN VALUE
 *	None
 */
node *free_list(node *head)
{
	node *tmpPtr = head;
	node *followPtr;

	while ( tmpPtr != NULL )
	{
		followPtr = tmpPtr;
		tmpPtr = tmpPtr->next;
		free(followPtr);
	}
	return NULL;
}

/*
 * FUNCTION
 *	void print_intro(char source[])
 * DESCRIPTION
 *	displays introduction for program output
 * PARAMETERS
 *	char source[] - character string containing the name of the source
 *			code file - argv[1]
 * RETURN VALUE
 *	None
 */
void print_intro(char source[])
{
	printf("\nFnLoC 2.3\n");
	printf("Copyright 2018, Richard B. Romig\n");
	printf("Licensed under the GNU General Public License, version 2\n\n");
	printf("Lines of code data for %s\n\n", source);
}

/*
 * FUNCTION
 *	void print_fn_data(char source[], int fn_count, int prg_loc)
 * DESCRIPTION
 *	displays function named loc contained in the function.
 *	if there are no functions displays a message to that effect and
 *	displays total lines of coded found in the source file.
 * PARAMETERS
 *	char source[] - character string containing the name of the source
 *			code file - argv[1]
 *	int fn_count - number of functions found
 *	int prg_loc - total lines of code counted in the source file
 * RETURN VALUE
 *	None
 */
void print_fn_data(char source[], int fn_count, int prg_loc)
{
	node *current;
	current = head;

	if ( fn_count == 0 )
	{
		printf("%s does not contain function code.\n\n", source);
		printf("Total Program LOC:   %4d\n\n", prg_loc);
	}
	else
	{
		printf("Functions:\n");
		while ( current != NULL )
		{
			printf("%s", current->name1);
			if ( strcmp(current->name2, "") != 0 )
				printf("%s", current->name2);
			printf("LOC:\t%4d\n", current->loc);
			current = current->next;
		}
	}
}

/*
 * FUNCTION
 *	void print_summary(int fn_count, int total_fn_loc, int prg_loc)
 * DESCRIPTION
 *	displays a summary of loc data.
  * PARAMETERS
 *	int fn_count - number of functions found
 *	int fn_loc - total lines of code counted for all functions
 *	int prg_loc - total lines of code counted in the source file
 * RETURN VALUE
 *	None
 */
void print_summary(int fn_count, int total_fn_loc, int prg_loc)
{
	printf("\nSummary:\n");
	printf("Number of functions: %4d\n", fn_count);
	printf("Function LOC:        %4d\n", total_fn_loc);
	printf("Non-function LOC:    %4d\n", prg_loc - total_fn_loc);
	printf("Total Program LOC:   %4d\n", prg_loc);
}
