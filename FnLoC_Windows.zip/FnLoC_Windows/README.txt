FnLoC - Counts Lines of Code
Counts lines of code and functions in C and C++ source code files
Richard Romig

1. Description:

FnLoC is a command-line program that counts logical lines of code in C and
C++ source code files that runs in a terminal. The program counts lines of
code in C/C++ source code disregarding comments and blank lines. It also
counts and lists functions by name with their respective lines of code.

The program assumes that the code is written according to modern C coding
standards as illustrated in The C Programming Language, 2nd edition by
Brian W. Kernighan & Dennis M. Ritchie.

Comments and blank lines are not counted as lines of code. The programs
takes into account both C and C++ style comments /* .... */ and // .....

Braces '{}' on lines by themselves are not counted as lines of code.

2. Installation:

Unzip the 'FnLoC-install-files' directory by righ-clicking FnLoC-install-files.zip,
selecing 'Extract All...' from the menu, and extractin to the recommended folder.

Launch FnLoC-install.bat as admilnistrator from inside the FnLoC-install-files
from within the either Windows File Explore or from the command line (run as
administrator). The batch file will create a C:\Tools folder if it doesn't
already exist and add the folder to the path. It will copy fnloc.exe to this
folder and its documentation files to C:\Tools\FnLoC\. A reboot is required for
the addition to the path to take effect.

Alternatively, you can simply copy fnloc.exe to a follder of your choice. A
folder that's already in your PATH environment will make using the program more
convenient.

3. Un-installation

The FnLoC-uninstall.bat script will remove FnLoC if it was installed with
FnLoC-install.bat as explained above.

Open the 'FnLoC-install-files' directory and click on FnLoC-uninstall.bat or
run the batch file from a commandn promopt.The script will guide you from there.

Errors reported in this script just mean it could not find all of the FNLOC
files. This usually means FnLoC was not installed with FnLoC-install.bat and it
will have to be removed manually.

5. SYNTAX

To display the lines of code information of a C source code file:
            fnloc.exe sourcefile.c

The results can be redirected to a file by redirecting the output:
            fnloc.exe source.c > loc.txt

The results for fnloc.c can be found in the documentation.

To get help and view the syntax:
            fnloc.exe -h
            fnloc.exe --help

If you don't include an argument or if the program fails to open the file you
give it will also call up the help.

6. PROGRAM LIMITATIONS

        a. Functions are expected to be in the following style:

        int function_name(int x, int y)
        {
                statements....
        }

        - This is the format recommended by Linus Torvalds in 'Linux Kernel
        Coding Style' and is based on the style used by K&R in 'The C
        Programming Language, 2nd Edition'.
        (https://www.kernel.org/doc/html/v4.10/process/coding-style.html)

        - If the opening brace '{' is on the same line as the function name
        and parameters, it will not be seen as a function. The lines of code
        will be counted but as code outside of a function.

        - The program will properly count and display function headers that are
          split over two lines. Functiion headers should be limited to one or
          two lines of less than 128 characters each. The buffer limit is set to
          128 characters. However, restraining function headers to a single line
          and 80 characters or less is a good practice.

    b. Data structures should be in the following style:

        struct {
                int len;
                char *str;
        } data;

        - This is the style used by Kernighan & Ritchie in The C Programming
        Language, 2nd edition.

        - The GNU C coding standard suggests placing the opening brackets are
        at the beginning of a line. However, FNLOC will incorrectly identify
        a structure written in this style as a function.

        - In data structure declarations such as arrays or enumerated types in
        which the data elements are delimited by commas, the elements inside
        the braces are not counted if they are not on the same line as a brace.

        Example:
        int days[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        is a single line of code.

        int days[12] = {
                            31, 28, 31, 30, 31, 30,
                            31, 31, 30, 31, 30, 31
                        };
        is seen as a two lines of code (the first and last lines).

    c. Conditional statements and for loops without braces and only one
    statement following are counted as one line of code.

    /* This will be seen as a one logical line of code */
    if ( condition )
        action;

    /* This will be seen as a one logical line of code */
    for ( i=1; i < 10; i++ )
        if ( condition )
            action;

    /* The will be seen as 4 logical lines of code - if (condition), action1,
    and action2. The else-action3 is one logical line of code. */
    if ( condition )
    {
        action1;
        action2;
    }
    else
        action3;

Feedback:

Feel free to contact me with comments and suggestions for FNLOC. Also feel free
to share any code that will help me improve this program.

Rick's Tech Stuff: https://ricktech.wordpress.com
Email: rick.romig@gmail.com
Twitter: @ludditegeek

Richard Romig
3 September 2018

DISCLAIMER

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL I BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS AND SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
