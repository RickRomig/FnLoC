FnLoC - Counts Lines of Code
Counts lines of code and functions in C and C++ source code files
Richard Romig

1. Description:

FnLoC is a program that runs from a command-line which counts logical lines of code in C and C++ source code files disregarding comments and blank lines. It also counts and lists functions by name displaying their respective lines of code. The program assumes that the code is written according to modern C coding standards as illustrated in The C Programming Language, 2nd edition by Brian W. Kernighan & Dennis M. Ritchie. Comments and blank lines are not counted as lines of code. The programs takes into account both C and C++ style comments. Lines containing only opening or closing braces ({}) are not counted as lines of code.

LLoC is an accompanying program that simply counts logical lines of source code, disregarding blank lines and comments without the breakdown into functions.

2. Installation:

Extract the FnLoC_Windows.zip, this create the FnLoC_Windows folder containing all the files. Right-clicking the zipped file and selecing 'Extract All...' from the menu will extract the files to the folder.

Launch FnLoC-install.bat as administrator from inside the FnLoC_Windows folder
from within the either Windows File Explore or from a command prompt (run as
administrator). The batch file will create a C:\Tools folder if it doesn't
already exist and add the folder to the path. It will copy fnloc.exe to this
folder and its documentation files to C:\Tools\FnLoC\. A reboot is required for
the addition to the path to take effect.

Alternatively, you can simply copy fnloc.exe to a follder of your choice. A
folder that's already in your PATH environment will make using the program more
convenient.

3. Removal

The FnLoC-uninstall.bat script will remove FnLoC if it was installed with
FnLoC-install.bat as explained above.

Open the FnLoC_Windows folder and click on FnLoC-uninstall.bat or
run the batch file from a command promopt. The script will guide you from there.

Errors reported in this script just mean it could not find all of the FNLOC
files. This usually means FnLoC was not installed with FnLoC-install.bat and it
will have to be removed manually.

5. Syntax

To display the lines of code information of a C source code file:
        fnloc.exe sourcefile.c

To get a general count of logical lines of code in your C source file:
        lloc.exe sourcefile.c

The results can be redirected to a file by redirecting the output:
            fnloc.exe source.c > loc.txt

The results for fnloc.c and lloc.c can be found in their respective .loc files.

To get help and view FnLoC or LLoC syntax, type the program name followed by either -h or --help.

If you don't include an argument or if the program fails to open the file you
give it will also call up the help.

6. Progam limitations

Functions are expected to be in the following style:

        int function_name(int x, int y)
        {
                statements....
        }

This is the format recommended by Linus Torvalds in 'Linux Kernel Coding Style' and is based on the style used by K&R in 'The C Programming Language, 2nd Edition'. (https://www.kernel.org/doc/html/v4.10/process/coding-style.html)

If the opening brace '{' is on the same line as the function name and parameters, it will not be seen as a function. The lines of code will be counted but as code outside of a function.

The program will properly count and display function headers that are split over two lines. Functiion headers should be limited to one or two lines of less than 128 characters each. The buffer limit is set to 128 characters. However, restraining function headers to a single line and 80 characters or less is a good practice.

Data structures should be in the following style:

    struct {
        int len;
        char *str;
    } data;

This is the style used by Kernighan & Ritchie in The C Programming Language, 2nd edition.

The GNU C coding standard suggests placing the opening brackets are at the beginning of a line. However, FNLOC will incorrectly identify a structure written in this style as a function.

In data structure declarations such as arrays or enumerated types in which the data elements are delimited by commas, the elements inside the braces are not counted if they are not on the same line as a brace.

Example:
    int days[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    /* counted as a single line of code */

    int days[12] = {31, 28, 31, 30, 31, 30,
                    31, 31, 30, 31, 30, 31 };
    /* counted as two lines of code */

    int days[12] = {
        31, 28, 31, 30, 31, 30,
        31, 31, 30, 31, 30, 31
    };
    /* counted as two lines of code (the first and last lines) */

Conditional statements and for loops without braces and only one statement following are counted as one line of code.

    if ( condition )
        action;
    /* This will be seen as a one logical line of code */

    for ( i=1; i < 10; i++ )
        if ( condition )
            action;
    /* This will be seen as a one logical line of code */

    while ( condition )
        action;
    /* This is seen as a one logical line of code */

    do
        action;
    while ( condition );
    /* This is seen as two logical lines of code */

    if ( condition )
    {
        action1;
        action2;
    }
    else
        action3;
    /* This is seen as 4 logical lines of code: (1) if ( condition ), (2) action1,
       (3) action2, (4) else-action3 */

Conditional and loop statements (if, else, for, while, do-while) where the opening brace is the first non-whtespace character on the line immediately following are counted as a line of code. Conditional statements and loop constructs can have the opening brace at either the end of the line or on the following line as long as it is not the very first character of the line (buffer[0]).

        while ( condition )
        {
                action1;
                action2;
        }

        while ( condition ) {
                action1;
                action2;
        }

LLoC is more lenient about coding style than FnLoC since it isn't concerned with the syntax for functions. However, data structure definitions, particularly those for arrays and enumerated types are counted exacly the same.

Feedback:

Feel free to contact me with comments and suggestions for FnLoC. Also feel free to share any code or ideas that will help me improve this program. I can be reached through my blog, Twitter, and email.

My GitHub repository: https://github.com/RickRomig/FnLoC
Rick's Tech Stuff: https://ricktech.wordpress.com
Email: rick.romig@gmail.com
Twitter: @ludditegeek https://twitter.com/ludditegeek

Richard Romig
25 January 2019

DISCLAIMER

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL I BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS AND SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
