#!/bin/bash

# fnloc-install.sh
# installs fnloc

echo "FnLoC Installation Script"
echo "Copyright 2018, Richard B. Romig"
echo "================================"
echo "Installing fnloc and loc2file ..."
sudo cp -v fnloc /usr/local/bin/
sudo cp -v loc2file /usr/local/bin/
# Copy source code to /usr/local/src/fnloc/
echo "Copying FnLoC source code ..."
if [ ! -d /usr/local/src/fnloc/ ]; then
	sudo mkdir -p -v /usr/local/src/fnloc
fi
sudo cp -v fnloc.{c,cpp,h} /usr/local/src/fnloc/
# Copy documentation to /usr/local/doc/fnloc/
echo "Copying FnLoC documentation ..."
if [ ! -d /usr/local/doc/fnloc/ ]; then
	sudo mkdir -p -v /usr/local/doc/fnloc
fi
sudo cp -v changelog /usr/local/doc/fnloc/
sudo cp -v README /usr/local/doc/fnloc/
sudo cp -v fnloc.loc /usr/local/doc/fnloc/
sudo cp -v LICENSE /usr/local/doc/fnloc/
sudo cp -v WARRANTY.txt /usr/local/doc/fnloc/
echo "FnLoC installed."
exit
