#!/bin/bash

# fnloc-uninstall.sh
# uninstalls fnloc

echo "FnLoC Un-Install Script"
echo "Copyright 2018, Richard B. Romig"
echo "================================"
# Remove program files
if [ ! -e /usr/local/bin/fnloc ]; then
	echo "fnloc not installed."
else
	echo "Uninstalling fnloc..."
	sudo rm -v /usr/local/bin/fnloc
fi

if [ ! -e /usr/local/bin/loc2file ]; then
	echo "loc2file not installed."
else
	echo "Uninstalling loc2file..."
	sudo rm -v /usr/local/bin/loc2file
fi
# Remove source code files and directory
if [ -d /usr/local/src/fnloc/ ]; then
    	echo "Removing program source code."
	sudo rm -rv /usr/local/src/fnloc/
fi
# Remove documentation files and directory
if [ -d /usr/local/doc/fnloc/ ]; then
	echo "Removing program documentation."
	sudo rm -rv /usr/local/doc/fnloc
fi
echo "fnloc uninstalled."
sleep 5
exit
